/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/JSF/JSFManagedBean.java to edit this template
 */
package loginJSF;
import javax.faces.bean.ManagedBean;

@ManagedBean
public class loginScreen {

    String username,password;

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }
    public String getPassword() {
        return password;
    }
    public void setPassword(String password) {
        this.password = password;
    }

    
    public String login() {
        if(username.equals("Sema")&&password.equals("1234")){
            return "Sisteme girisiniz basariyla gerceklesmistir.";
        }
        else{
            return "Kullanici adi ya da sifre hatali. Tekrar deneyin.";
        }
    }
    
}
